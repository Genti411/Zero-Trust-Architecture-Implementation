## Device Posture Policy
- Firmware must be current
- TLS must be enforced
- Devices must have unique identity
