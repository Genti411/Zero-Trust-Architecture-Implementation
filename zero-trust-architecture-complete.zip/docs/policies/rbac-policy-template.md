## RBAC Template
- **Role**: Admin
- **Permissions**: Read/Write to all zones
- **Conditions**: MFA enabled, VPN connected
