## MFA Requirements
- All privileged accounts must use MFA
- Supported methods: TOTP, Push Notification, Hardware Token
